AKIRA — SECURITY RESEARCH / LOCAL DESIGN V1
==========================================

Contents:
  layouts/partials/home_info.html  -- homepage hero; uses your existing hugo.toml text and social links
  assets/css/extended/akira.css   -- appearance for homepage, nav, cards, and article pages
  static/images/akira-fuji.svg    -- original, lightweight artwork

The package does NOT edit your posts, hugo.toml, PaperMod theme or GitHub Actions.

1) From the ROOT of your Hugo repository, first check for existing files:

   ls -l layouts/partials/home_info.html assets/css/extended/akira.css static/images/akira-fuji.svg 2>/dev/null

   If any exist, back them up before extracting. The files are meant to be new.

2) Unzip from the repo root, for example:

   unzip -n ~/Downloads/akira-hugo-local-v1.zip -d .

   -n means do NOT overwrite any existing files.

3) Start Hugo locally:

   hugo server -D --disableFastRender

   Open http://localhost:1313/ and also a full article page. Resize your browser.
   Important: Hugo 'server -D' includes drafts locally, which live builds exclude.

4) Don't run git add/commit/push yet: review locally first.

5) To revert this exact package if these paths did not exist before:

   rm layouts/partials/home_info.html assets/css/extended/akira.css static/images/akira-fuji.svg

Notes:
- PaperMod's social_icons.html partial is reused as-is.
- Layout only replaces the theme's home_info partial.
- Hugo Extended not required for this package; it works with your installed version.
- CSS uses the existing PaperMod pipeline, no npm or fonts downloaded.
- The illustration is a new custom SVG (not a copy of the earlier concept illustration).
